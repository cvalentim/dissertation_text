

for i in 1 2 3 4 5 6
do
#mv "real_fpair.s$i.csv" "real_s$i//"
mv "beg_result_real_fpair.s$i.csv" "real_s$i"
mv "beg_result_real_rmqSt.s$i.csv" "real_s$i//"
mv "beg_result_real_rmqNaive.s$i.csv" "real_s$i//"
#mv "random_fpair.s$i.csv" "random_s$i//"
#mv "random_rmqNaive.s$i.csv" "random_s$i//"
#mv "random_rmqSt.s$i.csv" "random_s$i//"
done
